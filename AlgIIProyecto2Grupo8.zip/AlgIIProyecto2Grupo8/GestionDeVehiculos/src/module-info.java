/**
 * 
 */
/**
 * 
 */
module GestionDeVehiculos {
	requires java.desktop;
}