package gestion;

public class NodoCond {
   private Condiciones CondObstaculos;
   private NodoCond proximo;
   
   public NodoCond() {
	   
   }
   
   public NodoCond (Condiciones CondObstaculos,NodoCond proximo) {
	   this.CondObstaculos = CondObstaculos;
	   this.proximo = proximo;
   }

public Condiciones getCondObstaculos() {
	return CondObstaculos;
}

public void setCondObstaculos(Condiciones condObstaculos) {
	CondObstaculos = condObstaculos;
}

public NodoCond getProximo() {
	return proximo;
}

public void setProximo(NodoCond proximo) {
	this.proximo = proximo;
}
}

