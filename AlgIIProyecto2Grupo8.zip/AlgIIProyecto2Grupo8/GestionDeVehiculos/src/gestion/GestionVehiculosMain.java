package gestion;


import java.io.IOException;
import java.util.Scanner;


public class GestionVehiculosMain {
	 static ListaVehiculos listaV = new ListaVehiculos();
	 static ListaCond listaC = new ListaCond();

	
	public static void main(String[] args) throws IOException {
		    int opc = 0,opcion1 = 0,opcion2;
		    String nombre,name,nConductor,tipo = null,tamano = null,velocidad = null, strOpcion1;
		    int cantidad,resObstaculos = 0,resExplosivo = 0,resLiquido=0,velocidadkm = 0;
		    boolean log,log1;
		    NodoCond aux;
		  
			    
			    listaV = listaV.leerArchivo(listaV);
			    listaC = listaC.leerArchivo2(listaC);
			    do {
			    	@SuppressWarnings("resource")
			  
					Scanner input = new Scanner (System.in);
			        System.out.println("\n*****     APLICACIÓN DE GESTIÓN DE VEHÍCULOS     ******\n");
			        System.out.println("1. Agregar Vehiculo Nuevo");
			        System.out.println("2. Modificar Vehiculo");
			        System.out.println("3. Eliminar Vehiculo");
			        System.out.println("4. Mostrar Lista");
			        System.out.println("5. Consultar Vehiculo"); 
			        System.out.println("6. Salir de <Gestión de Vehículos>");
			        System.out.println("¿Qué opcion desea elegir?");
			     //   if (input.hasNextInt()) {
			            //input.nextLine();
			            opc = input.nextInt();
			            switch(opc) {
			            case 1: 
			            	System.out.println("*****     AGREGANDO NUEVO VEHICULO     *****\n");
			            
			            do{
			            	
			            	System.out.println("\nNombre en español: ");
			                nombre = input.next();
			               
			                log = validarNombre(listaV.getListaVehiculos(),nombre);
			                log1 = cadenaValida(nombre);
			                if (log == false) {
			                	System.out.println("El nombre indicado ya existe. Intente de nuevo");
			                } else if (log1 == false) {
			                	System.out.println("Escriba una cadena valida que no consista solo de espacios en blanco.");
			                }
			            }while ((log == false) || (log1 == false));
	
			                do{
			                System.out.println("\nNombre en ingles: ");
			                name = input.next();
			                log = validarName(listaV.getListaVehiculos(),name);
			                log1 = cadenaValida(name);
			                if (log == false) {
			                	System.out.println("El nombre indicado ya existe. Intente de nuevo");
			                }else if (log1 == false) {
			                	System.out.println("Escriba una cadena valida que no consista solo de espacios en blanco.");
			                }
			                }while((log == false) || (log1 == false));

			                do {
			                	System.out.println("\nNombre del o los conductores: "); 
			                nConductor = input.next();
			                log = cadenaValida(nConductor);
			                if (log == false) {
			                	System.out.println("Nombre no valido");
			                }
			                }while(log == false);
		
			                do {
			                	try (Scanner input1 = new Scanner (System.in)) {
									System.out.println("\nA continuacion elija una de las siguientes opciones: ");
            listaC.imprimirCondiciones(listaC.getListaCond());
            opcion1 = input1.nextInt();
								}
			                	if ((opcion1 > 9) || (opcion1 < 1)){
			                	System.out.println("Opcion Invalida");
			                } else {
			                	
			                aux = listaC.buscarNodo2(listaC.getListaCond(),opcion1);
			                velocidad = aux.getCondObstaculos().getVelocidad();
			                tipo = aux.getCondObstaculos().getTipoCaucho();
			                tamano = aux.getCondObstaculos().getTamanoCaucho();
			                resObstaculos = aux.getCondObstaculos().getObstaculo();
			                resLiquido = aux.getCondObstaculos().getLiquido();
			                resExplosivo = aux.getCondObstaculos().getExplosivo();
			                velocidadkm = aux.getCondObstaculos().getVelocidadkm();
			                
			                }
			                } while((opcion1 > 9) || (opcion1 < 1));

			                listaV.agregarNodo(listaV.getListaVehiculos(), nombre, name, nConductor, tipo, tamano, velocidad, resObstaculos, resLiquido, resExplosivo, velocidadkm);
			                listaV.imprimirListaCarros();
			                listaV.actualizarArchivo(listaV.getListaVehiculos());
			                listaV.mostrarDatosAgregados(listaV.getListaVehiculos());
			           
			            
			        break;

			        case 2:
			        	
			        	System.out.println("*****     MODIFICAR VEHÍCULO     *****\n");
			            cantidad = listaV.contarNodos(listaV.getListaVehiculos());
			            listaV.enumerarNodos(listaV.getListaVehiculos());
			            if (cantidad == 11) {
			            	System.out.println("No existen vehiculos por modificar");
			            } else {
			            do{
			            	System.out.println("¿Qué vehículo desea modificar?");
			                strOpcion1 = input.next();
			                opcion1 = Integer.parseInt(strOpcion1);
		
			            }while ((opcion1 > cantidad) || (opcion1 < 1));

			            listaV.enumerarElementoNodo(listaV.getListaVehiculos(),opcion1+11);
			           
			                do{
			                	System.out.println("¿Qué atributo del vehículo desea modificar?");
			                    opcion2 = input.nextInt();
			                    if  ((opcion2>6) || (opcion2<1)){
			                    	System.out.println("Opción Inválida");
			                    }
			                } while ((opcion2>6) || (opcion2<1));
			                
			                modificarDatos(listaV,listaC,opcion1+11,opcion2);
			                System.out.println("\n¡Se ha logrado la modificación exitosamente!"); 
			                System.out.println("\nLos datos del vehiculo actualizados ahora son: ");
			                listaV.mostrarNodo(listaV.getListaVehiculos(),opcion1+11);
			            } 
			        break;

			        case 3:
	
			        	System.out.println("*****     ELIMINANDO VEHICULO     *****\n");
			        	   cantidad = listaV.contarNodos(listaV.getListaVehiculos());
				           listaV.enumerarNodos(listaV.getListaVehiculos());
			            do{
			            	System.out.println("¿Qué vehiculo desea eliminar?");
			                strOpcion1 = input.next();;
			                opcion1 = Integer.parseInt(strOpcion1);

			            }while((opcion1 > cantidad) || (opcion1 < 1));
			         
			                System.out.println("Vehículo eliminado exitosamente");
			                System.out.println("*****     VEHÍCULO ELIMINADO     *****");
			                listaV.mostrarNodo(listaV.getListaVehiculos(),opcion1+11);
			                listaV.eliminarNodo(listaV.getListaVehiculos(),opcion1+11);

			        break;

			        case 4: 
			        	System.out.println("*****     MOSTRANDO TODOS LOS VEHICULOS EXISTENTES         *****\n");
			        	System.out.println("Presione Enter para regresar");
			            listaV.imprimirListaCarros();

			        break;
			       
			        case 5:
			        	System.out.println("*****     CONSULTA DE VEHICULOS     *****\n");
			        	   cantidad = listaV.contarNodos(listaV.getListaVehiculos());
				           listaV.enumerarNodos2(listaV.getListaVehiculos());
			            do {
			            	System.out.println("\n¿Qué vehiculo desea consultar?");
			                strOpcion1 = input.next();
			                opcion1 = Integer.parseInt(strOpcion1);
			            }while((opcion1 > cantidad) || (opcion1 < 1));
			                listaV.mostrarNodo(listaV.getListaVehiculos(),opcion1);

			            
			        break;

			        case 6: 

			        break;

			        default: 
			  
			        	System.out.println("Oh no! Usted ha elegido una opción invál ida. Intente de nuevo :)");
			        }
			        //}
			        //else {
			         //   	System.out.println("Entrada de datos incorrecta");
			       // }
			    }while ((opc != 6));
			    
			    System.out.println("Está saliendo del menú <GESTIÓN DE VEHÍCULOS>");
			    System.out.println("Disfrute de la carrera!");

}
	
	public static boolean stringIguales(String cadena1, String cadena2) {
	    if (cadena1.length() != cadena2.length()) { 
	        return false;
	    }
	    for (int i = 0; i < cadena1.length(); i++) {
	        if (cadena1.charAt(i) != cadena2.charAt(i)) { 
	            return false;
	        }
	    }
	    return true; 
	}
	
	public static boolean validarNombre(Nodo lista,String dato) {
		   Nodo aux = lista;
		   boolean validar = true;
		   while (aux != null) {
		    if (stringIguales(dato,aux.getVehiculo().getNombreEspanol())){
		       validar = false;
		    } 
		    aux = aux.getProximo();
		   }
		   return validar;
		}
	
	public static boolean validarName(Nodo lista,String dato) {
		   Nodo aux = lista;
		   boolean validar = true;
		   while (aux != null) {
		    if (stringIguales(dato,aux.getVehiculo().getNombreIngles())){
		       validar = false;
		    } 
		    aux = aux.getProximo();
		   }
		   return validar;
		}
	
	public static boolean esEntero(String linea) {
		boolean esEntero = true;
		int longitud = linea.length();
		
		if (longitud == 0) {
			esEntero = false;
		} else if (longitud == 1 && !Character.isDigit(linea.charAt(0))) {
			esEntero = false;
		} else {
			int indice = 0;
			if (linea.charAt(0) == '+' || linea.charAt(0) == '-') {
				indice = 1;
			} else {
				indice = 0;
			}
			while (indice < longitud) {
				if (!Character.isDigit(linea.charAt(indice))) {
					esEntero = false;
					break;
				}
				indice++;
			}
		}	
		return esEntero;	
	}

	public static boolean soloEspacios(String str) {
	    for (int i = 0; i < str.length(); i++)
	        if (str.charAt(i) != ' ')
	            return true;
	    return false;
	}
	
	   public static boolean cadenaValida(String dato){
	        if (dato.isEmpty())
	           return false;
	        else
	          if (soloEspacios(dato) == false)
	             return false;
	          else 
	             return true;   
	    }
	   
	   public static boolean figurasObstaculos (char fig) {
		    boolean valor = true;
		    if ((fig =='*') || (fig == '=') || (fig == '<')) {
		        valor = false;
		    }
		    return valor;
		}

  
	public static void modificarTipoCarro (ListaVehiculos lista, ListaCond lista2, int opcion,int opcion1) {
	    Nodo actual = lista.buscarNodo(lista.getListaVehiculos(),opcion1);
	    NodoCond aux;
	            aux = lista2.buscarNodo2(lista2.getListaCond(),opcion);
	            actual.getVehiculo().setVelocidad(aux.getCondObstaculos().getVelocidad());
	            actual.getVehiculo().setTipoCaucho(aux.getCondObstaculos().getTipoCaucho());
	            actual.getVehiculo().setTamanoCaucho(aux.getCondObstaculos().getTamanoCaucho());
	            actual.getVehiculo().setResObstaculos(aux.getCondObstaculos().getObstaculo());
	            actual.getVehiculo().setResLiquido(aux.getCondObstaculos().getLiquido());
	            actual.getVehiculo().setVelocidadkm(aux.getCondObstaculos().getVelocidadkm());
	}
	
	
	public static void modificarDatos(ListaVehiculos lista,ListaCond lista2, int opcion1, int opcion2) throws IOException {
		    Nodo actual = lista.buscarNodo(lista.getListaVehiculos(),opcion1);
		    boolean log,log1= false;
		    int opcion;
		    try (Scanner input = new Scanner (System.in)) {
				switch (opcion2) {
				case 1:
				do{
				System.out.println("¿Cuál quiere que sea el nuevo nombre del vehiculo?");
				String atributoModificado = input.next();
				log = validarNombre(lista.getListaVehiculos(),atributoModificado);
				log1 = cadenaValida(atributoModificado);
				if(log == false) {
				  System.out.println("Este nombre no es valido ya que se encuentra repetido. Intente de nuevo");
				}
				if (log1 == false) {
				    System.out.println("Error. Intente de nuevo escribiendo una cadena valida sin puros espacios en blanco.");
				}
				if ((log) && (log1)){
				  actual.getVehiculo().setNombreEspanol(atributoModificado); 
				}
				}while((log == false) || (log1 == false));
				break;

				case 2: 
				do{
				System.out.println("¿Cuál quiere que sea el nuevo nombre en ingles del vehiculo?");
				String atributoModificado = input.next();
				log = validarName(lista.getListaVehiculos(),atributoModificado);
				log1 = cadenaValida(atributoModificado);
				if(log == false) {
					System.out.println("Este nombre no es valido ya que se encuentra repetido. Intente de nuevo");
				  }
				if (log1 == false) {
					System.out.println("Error. Intente de nuevo escribiendo una cadena válida sin puros espacios en blanco.");
				}  

				if ((log) && (log1)){
				  actual.getVehiculo().setNombreIngles(atributoModificado); 
				}
				}while((log == false) || (log1 == false));
				break;

				case 3: 
				do{
				System.out.println("¿Cuál quiere que sea el nuevo nombre del conductor?");
				String atributoModificado = input.next();
				log = cadenaValida(atributoModificado);
				if(log == false) {
					System.out.println("Error. Esta escribiendo puros espacios en blanco. Intente de nuevo escribiendo un nombre valido.");
				} else {
				  actual.getVehiculo().setNombreConductor(atributoModificado); 
				}
				}while(log == false);
				break;

				case 4:  
				System.out.println("\nAl cambiar el tipo de caucho, es necesario modificar el tipo de carro.");
				do{
				System.out.println("\nElija una de las opciones mostradas: "); 
				lista2.imprimirCondiciones(lista2.getListaCond());  
				opcion = input.nextInt();
				if ((opcion > 9) || (opcion< 1)){
				System.out.println("Opcion Inválida. Intente de nuevo.");
				}else
				modificarTipoCarro(lista,lista2,opcion,opcion1);
				}while((opcion > 9) || (opcion < 1));
				break;

				case 5: 
				System.out.println("\nAl cambiar el tamano de caucho, es necesario modificar el tipo de carro.");
				do{
				System.out.println("\nElija una de las opciones mostradas:"); 
                lista2.imprimirCondiciones(lista2.getListaCond());  
				 opcion = input.nextInt();
				if ((opcion > 9) || (opcion < 1)){
				System.out.println("Opcion Invalida. Intente de nuevo.");
				}else
				modificarTipoCarro(lista,lista2,opcion,opcion1);
				}while((opcion > 9) || (opcion < 1));
				break;

				case 6: 
				System.out.println("\nAl cambiar la velocidad, es necesario modificar el tipo de carro.");
                lista2.imprimirCondiciones(lista2.getListaCond());  
				do{
				System.out.println("\nElija una de las opciones mostradas: "); 
				 opcion = input.nextInt();
				if ((opcion > 9) || (opcion < 1)){
				System.out.println("Opcion Invalida. Intente de nuevo.");
				}else
				modificarTipoCarro(lista,lista2,opcion,opcion1);
				}while((opcion > 9) || (opcion < 1));
				break;

				default: System.out.println("Opcion Invalida");
    }
			}
		    
		    lista.actualizarArchivo(lista.getListaVehiculos());
	}
	
	public static void regresarSalir(boolean regresar, boolean salir, boolean valorInvalido, int cantidad, String strOpcion1, int opcion1){
	    if(esEntero(strOpcion1)){
	        opcion1=Integer.parseInt(strOpcion1);
	        if ((opcion1 > cantidad) || (opcion1 < 1)) {
	            valorInvalido=true;
	        }
	    }else{
	        if (strOpcion1.length()==1){
	            if (strOpcion1.charAt(0)=='R'||(strOpcion1.charAt(0)=='r')){
	                regresar=true;
	               // system("clear");
	            }else {
	                if (strOpcion1.charAt(0)=='S'||(strOpcion1.charAt(0)=='s')){
	                    salir=true;
	                }else
	                    valorInvalido=true;
	            }
	        }
	    }
	}

}



