package gestion;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class MenuPrincipal extends JFrame {
	
 ListaVehiculos listaV = new ListaVehiculos();
 ListaCond listaC = new ListaCond();
 
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MenuPrincipal frame = new MenuPrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MenuPrincipal() {
		listaV = listaV.leerArchivo(listaV);
	    listaC = listaC.leerArchivo2(listaC);
	    
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		
		JButton btnNewButton = new JButton("1. Agregar Vehiculo");
		btnNewButton.setBounds(128, 36, 168, 23);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
			}
		});
		contentPane.setLayout(null);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("Menu Principal");
		lblNewLabel.setFont(new Font("Franklin Gothic Medium", Font.BOLD, 18));
		lblNewLabel.setBounds(152, 11, 150, 14);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton_1 = new JButton("2. Modificar Vehiculo");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1.setBounds(128, 87, 168, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("3. Eliminar Vehiculo"); 
		btnNewButton_2.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        int cantidad = listaV.contarNodos(listaV.getListaVehiculos());
		        String strOpcion1;
		        int opcion1;
		        System.out.println(cantidad);
		        do {
		            strOpcion1 = JOptionPane.showInputDialog("¿Qué vehiculo desea eliminar?");
		            if (strOpcion1 == null) {
		                return;
		            }
		            try {
		                opcion1 = Integer.parseInt(strOpcion1);
		            } catch (NumberFormatException ex) {
		                opcion1 = -1; //
		                JOptionPane.showMessageDialog(null, "Ingrese un número válido");
		            }
		            System.out.println(opcion1);
		        } while (opcion1 > cantidad || opcion1 < 11);
		        
		        
		        System.out.println("Vehículo eliminado exitosamente");
		        System.out.println("*****     VEHÍCULO ELIMINADO     *****");
		        listaV.mostrarNodo(listaV.getListaVehiculos(), opcion1);
		        try {
		            listaV.eliminarNodo(listaV.getListaVehiculos(), opcion1);
		        } catch (IOException e1) {
		            e1.printStackTrace();
		        }
		    }
		});
		
		btnNewButton_2.setBounds(128, 132, 168, 23);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("4. Consultar Vehiculo");
		btnNewButton_3.setBounds(128, 180, 168, 23);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("5. Listar Vehiculos");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_4.setBounds(128, 227, 168, 23);
		contentPane.add(btnNewButton_4);
	}

}
