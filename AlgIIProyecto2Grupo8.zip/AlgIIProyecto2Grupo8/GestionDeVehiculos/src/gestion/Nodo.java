package gestion;

public class Nodo {
	private Vehiculos vehiculo;
	private Nodo proximo;
	
	public Nodo() {
		
	}
	
	public Nodo(Vehiculos vehiculo, Nodo proximo) {
		this.vehiculo = vehiculo;
		this.proximo = proximo;
	}

	public Vehiculos getVehiculo() {
		return vehiculo;
	}

	public void setVehiculo(Vehiculos vehiculo) {
		this.vehiculo = vehiculo;
	}

	public Nodo getProximo() {
		return proximo;
	}

	public void setProximo(Nodo proximo) {
		this.proximo = proximo;
	}

}
