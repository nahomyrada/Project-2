package gestion;

public class Condiciones {
	    String velocidad;
	    String tipoCaucho;
	    String tamanoCaucho;
	    int obstaculo;
	    int liquido;
	    int explosivo;
	    int velocidadkm;
	    
	    public Condiciones ( String velocidad, String tipoCaucho, String tamanoCaucho,int obstaculo, int liquido, int explosivo,int velocidadkm) {
	    	this.velocidad = velocidad;
	 	    this.tipoCaucho = tipoCaucho;
	 	    this.tamanoCaucho = tamanoCaucho;
	 	    this.obstaculo = obstaculo;
	 	    this.liquido = liquido;
	 	    this.explosivo = explosivo;
	 	    this.velocidadkm = velocidadkm;
	    }
	    
	    public Condiciones(Condiciones copia) {
	    	this.velocidad = copia.velocidad;
	    	this.tipoCaucho = copia.tipoCaucho;
	    	this.tamanoCaucho = copia.tamanoCaucho;
	       	this.obstaculo = copia.obstaculo;
	    	this.liquido = copia.liquido;
	    	this.explosivo = copia.explosivo;
	    	this.velocidadkm = copia.velocidadkm;
	    }
	    
	    public String getVelocidad() {
			return velocidad;
		}

		public void setVelocidad(String velocidad) {
			this.velocidad = velocidad;
		}

		public String getTipoCaucho() {
			return tipoCaucho;
		}

		public void setTipoCaucho(String tipoCaucho) {
			this.tipoCaucho = tipoCaucho;
		}

		public String getTamanoCaucho() {
			return tamanoCaucho;
		}

		public void setTamanoCaucho(String tamanoCaucho) {
			this.tamanoCaucho = tamanoCaucho;
		}

		public int getObstaculo() {
			return obstaculo;
		}

		public void setObstaculo(int bomba) {
			this.obstaculo = bomba;
		}

		public int getExplosivo() {
			return explosivo;
		}

		public void setExplosivo(int piedra) {
			this.explosivo = piedra;
		}

		public int getLiquido() {
			return liquido;
		}

		public void setLiquido(int liquido) {
			this.liquido = liquido;
		}

		public int getVelocidadkm() {
			return velocidadkm;
		}

		public void setVelocidadkm(int velocidadkm) {
			this.velocidadkm = velocidadkm;
		}

		public Condiciones() {
	    	
	    }
}
