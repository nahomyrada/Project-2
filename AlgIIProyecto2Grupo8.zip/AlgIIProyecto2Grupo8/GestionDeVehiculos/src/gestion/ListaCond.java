package gestion;

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class ListaCond {
  private NodoCond listaCond;
  
  public ListaCond () {
	  listaCond = null;
  }
  
  public NodoCond getListaCond() {
	  return listaCond;
  }
  
  
	public ListaCond leerArchivo2(ListaCond listaCond) {
        String nombreArchivo = "condObstaculos.txt";
        int cont=0;
        Condiciones listaTemporal = new Condiciones();
        ListaCond listaC = new ListaCond();
        try (Scanner scanner = new Scanner(new File(nombreArchivo))) {
            
            while (scanner.hasNextLine()) {
                String linea = scanner.nextLine(); cont++;
                switch(cont) {
                	case 1: listaTemporal.setVelocidad(linea); break;
                	case 2: listaTemporal.setTipoCaucho(linea); break;
                	case 3: listaTemporal.setTamanoCaucho(linea); break;
                	case 4: listaTemporal.setObstaculo(Integer.parseInt(linea)); break;
                	case 5: listaTemporal.setLiquido(Integer.parseInt(linea)); break;
                	case 6: listaTemporal.setExplosivo(Integer.parseInt(linea)); break;
                	case 7: listaTemporal.setVelocidadkm(Integer.parseInt(linea)); 
                	cont = 0; 
                	Condiciones copiaListaTemporal = new Condiciones(listaTemporal);
                	listaC.insertarFinal(copiaListaTemporal); 
                	break;
                }
            }
        } catch (FileNotFoundException e) {
            System.err.println("Archivo no encontrado: " + e.getMessage());
	        }
	    return listaC;
	}
	
	public void insertarFinal(Condiciones infoCond) {
		NodoCond nuevo = new NodoCond(infoCond,null);
		if (listaCond == null) 
			listaCond = nuevo;
		else{
			NodoCond aux = listaCond;
			while(aux.getProximo() != null) {
				aux =aux.getProximo();
			}	
			aux.setProximo(nuevo);
		}
	}
	
	public NodoCond buscarNodo2(NodoCond lista, int opcion){
	    NodoCond auxBuscar;
	    auxBuscar = lista;
	    int  i = 1;
	    while (auxBuscar != null && i != opcion) {
	    	auxBuscar = auxBuscar.getProximo();
	        i++;
	    }
	    return auxBuscar;
	}
	
	public void imprimirCondiciones(NodoCond lista) {
    System.out.printf("%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s\n", "OPCIONES", "VELOCIDAD", "TIPO CAUCHO", "TAMAÑO CAUCHO", "OBSTACULOS", "LIQUIDO", "BOMBA", "VELOCIDAD KM/H");
    System.out.println("_______________________________________________________________________________________________________________________________________________________");

    int i = 1;
    for (NodoCond actual = lista; actual != null; actual = actual.getProximo()) {
        System.out.printf("%-20d%-20s%-20s%-20s%-20s%-20s%-20s%-20s\n", i, actual.getCondObstaculos().getVelocidad(), actual.getCondObstaculos().getTipoCaucho(), actual.getCondObstaculos().getTamanoCaucho(),actual.getCondObstaculos().getObstaculo(),actual.getCondObstaculos().getLiquido(),actual.getCondObstaculos().getExplosivo(),actual.getCondObstaculos().getVelocidadkm());
        i++;
    }
}
	
	public void imprimirListaCarros() {
		NodoCond aux = listaCond;
		while (aux != null) {
			System.out.println(aux.getCondObstaculos().getTipoCaucho()+ " " +aux.getCondObstaculos().getTamanoCaucho()+ " "+ aux.getCondObstaculos().getVelocidad() + 
					" "+ aux.getCondObstaculos().getObstaculo() + " " + aux.getCondObstaculos().getLiquido() + " " + aux.getCondObstaculos().getLiquido()
					+ aux.getCondObstaculos().getVelocidadkm());
			aux=aux.getProximo();
		}
	}
	
  
}
