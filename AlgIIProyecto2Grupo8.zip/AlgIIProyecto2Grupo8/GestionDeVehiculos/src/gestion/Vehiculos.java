package gestion;

public class Vehiculos {
private String nombreEspanol;
private String nombreIngles;
private String nombreConductor;
private String tipoCaucho;
private String tamanoCaucho;
private String velocidad;
private int resObstaculos;
private int resLiquido;
private int resExplosivos;
private int velocidadkm;

public Vehiculos() {
	
}

public Vehiculos(Vehiculos copia) {
	this.nombreEspanol = copia.nombreEspanol;
	this.nombreIngles = copia.nombreIngles;
	this.nombreConductor = copia.nombreConductor;
	this.tipoCaucho = copia.tipoCaucho;
	this.tamanoCaucho = copia.tamanoCaucho;
	this.velocidad = copia.velocidad;
	this.resObstaculos = copia.resObstaculos;
	this.resLiquido = copia.resLiquido;
	this.resExplosivos = copia.resExplosivos;
	this.velocidadkm = copia.velocidadkm;
}
public Vehiculos(String nombreEspanol, String nombreIngles, String nombreConductor,String tipoCaucho,
		String tamanoCaucho, String velocidad, int resObstaculos,int resLiquido,int resExplosivos,int velocidadkm) {
	super();
	this.nombreEspanol = nombreEspanol;
	this.nombreIngles = nombreIngles;
	this.nombreConductor = nombreConductor;
	this.tipoCaucho = tipoCaucho;
	this.tamanoCaucho = tamanoCaucho;
	this.velocidad = velocidad;
	this.resObstaculos = resObstaculos;
	this.resLiquido = resLiquido;
	this.resExplosivos = resExplosivos;
	this.velocidadkm = velocidadkm;
}

public int getResObstaculos() {
	return resObstaculos;
}

public void setResObstaculos(int resObstaculos) {
	this.resObstaculos = resObstaculos;
}

public int getResLiquido() {
	return resLiquido;
}

public void setResLiquido(int resLiquido) {
	this.resLiquido = resLiquido;
}

public int getResExplosivos() {
	return resExplosivos;
}

public void setResExplosivos(int resExplosivos) {
	this.resExplosivos = resExplosivos;
}

public String getNombreEspanol() {
	return nombreEspanol;
}

public void setNombreEspanol(String nombreEspanol) {
	this.nombreEspanol = nombreEspanol;
}

public String getNombreIngles() {
	return nombreIngles;
}

public void setNombreIngles(String nombreIngles) {
	this.nombreIngles = nombreIngles;
}

public String getNombreConductor() {
	return nombreConductor;
}

public void setNombreConductor(String nombreConductor) {
	this.nombreConductor = nombreConductor;
}

public int getVelocidadkm() {
	return velocidadkm;
}

public void setVelocidadkm(int velocidadkm) {
	this.velocidadkm = velocidadkm;
}

public String getTipoCaucho() {
	return tipoCaucho;
}

public void setTipoCaucho(String tipoCaucho) {
	this.tipoCaucho = tipoCaucho;
}

public String getTamanoCaucho() {
	return tamanoCaucho;
}

public void setTamanoCaucho(String tamanoCaucho) {
	this.tamanoCaucho = tamanoCaucho;
}

public String getVelocidad() {
	return velocidad;
}

public void setVelocidad(String velocidad) {
	this.velocidad = velocidad;
}


}
