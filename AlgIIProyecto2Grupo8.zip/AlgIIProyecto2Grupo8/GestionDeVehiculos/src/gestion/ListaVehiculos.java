package gestion;

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

public class ListaVehiculos {
	private Nodo lista;
	
	public ListaVehiculos() {
		lista = null;
	}
	
	public Nodo getListaVehiculos() {
		return lista;
	}

	public ListaVehiculos leerArchivo(ListaVehiculos lista) {
        String nombreArchivo = "autosLocos2.txt";
        int cont=0;
        Vehiculos carroTemporal = new Vehiculos();
        ListaVehiculos listaCarros = new ListaVehiculos();
        try (Scanner scanner = new Scanner(new File(nombreArchivo))) {
            
            while (scanner.hasNextLine()) {
                String linea = scanner.nextLine(); cont++;
                switch(cont) {
                	case 1: carroTemporal.setNombreEspanol(linea); break;
                	case 2: carroTemporal.setNombreIngles(linea); break;
                	case 3: carroTemporal.setNombreConductor(linea); break;
                	case 4: carroTemporal.setTipoCaucho(linea); break;
                	case 5: carroTemporal.setTamanoCaucho(linea); break;
                	case 6: carroTemporal.setVelocidad(linea); break;
                	case 7: carroTemporal.setResObstaculos(Integer.parseInt(linea));break;
                	case 8: carroTemporal.setResLiquido(Integer.parseInt(linea)); break;
                	case 9: carroTemporal.setResExplosivos(Integer.parseInt(linea)); break;
                	case 10: carroTemporal.setVelocidadkm(Integer.parseInt(linea)); 
                	cont = 0;
                	Vehiculos copiaCarroTemporal = new Vehiculos(carroTemporal);
                	listaCarros.insertarFinal(copiaCarroTemporal); 
                	break;
                }
            }
        } catch (FileNotFoundException e) {
            System.err.println("Archivo no encontrado: " + e.getMessage());
	        }
	    return listaCarros;
	}

public void insertarFinal(Vehiculos infoCarro) {
	Nodo nuevo = new Nodo(infoCarro,null);
	if (lista == null) 
		lista = nuevo;
	else{
		Nodo aux = lista;
		while(aux.getProximo() != null) {
			aux =aux.getProximo();
		}	
		aux.setProximo(nuevo);
	}
}

	public Nodo buscarNodo(Nodo lista,int opcion) {
		Nodo aux;
		aux = lista;
		int i = 1;
		while(aux != null && i != opcion) {
			aux = aux.getProximo();
			i++;
		}
		return aux;
	}
	
	public void actualizarArchivo(Nodo lista) throws IOException {
	    Nodo actual = lista;
	    FileWriter archivoSalida = new FileWriter("autosLocos2.txt");
	    actual = lista;
	    while(actual != null) {
	        archivoSalida.write(actual.getVehiculo().getNombreEspanol() + "\n" + 
	            actual.getVehiculo().getNombreIngles() + "\n" +
	            actual.getVehiculo().getNombreConductor() + "\n" +
	            actual.getVehiculo().getTipoCaucho() + "\n" +
	            actual.getVehiculo().getTamanoCaucho() + "\n" +
	            actual.getVehiculo().getVelocidad() + "\n" +
	            actual.getVehiculo().getResObstaculos() + "\n" +
	            actual.getVehiculo().getResLiquido() + "\n" +
	            actual.getVehiculo().getResExplosivos() + "\n" +
	            actual.getVehiculo().getVelocidadkm() + "\n"); // Agrega una línea en blanco después de cada vehículo
	        actual = actual.getProximo();
	    }
	    archivoSalida.close();
	}

	public void agregarNodo(Nodo lista, String nombre, String name, String nConductor, String tipo, String tamano, String velocidad, int obstaculos, int liquido, int explosivos, int velocidadkm) {
	    Nodo nuevoNodo = new Nodo();
	    nuevoNodo.setVehiculo(new Vehiculos());
	    nuevoNodo.getVehiculo().setNombreEspanol(nombre);
	    nuevoNodo.getVehiculo().setNombreIngles(name);
	    nuevoNodo.getVehiculo().setNombreConductor(nConductor);
	    nuevoNodo.getVehiculo().setTipoCaucho(tipo);
	    nuevoNodo.getVehiculo().setTamanoCaucho(tamano);
	    nuevoNodo.getVehiculo().setVelocidad(velocidad);
	    nuevoNodo.getVehiculo().setResObstaculos(obstaculos);
	    nuevoNodo.getVehiculo().setResLiquido(liquido);
	    nuevoNodo.getVehiculo().setResExplosivos(explosivos);
	    nuevoNodo.getVehiculo().setVelocidadkm(velocidadkm);
	    nuevoNodo.setProximo(null);
	    
	    Nodo temp = lista;
	    while (temp.getProximo() != null) {
	        temp = temp.getProximo();
	    }
	    temp.setProximo(nuevoNodo);
	}
	
	public int contarNodos(Nodo lista) {
		Nodo actual = lista;
		int i = 0;
		
		while(actual != null) {
			i++;
			
			actual = actual.getProximo();
		}
		return i;
	}
	
	public void enumerarNodos2(Nodo lista) {
		Nodo actual = lista;
		int i = 0;
		
		while(actual != null) {
			i++;
		    System.out.println(i + ". " + actual.getVehiculo().getNombreEspanol());
			actual = actual.getProximo();
		}
	}
	
	
	public void enumerarNodos(Nodo lista) {
	    Nodo actual = lista;
	    int i = 0;
	    
	    while(actual != null && i < 11) {
	        actual = actual.getProximo();
	        i++;
	    }
	    
	    if (actual == null) {
	        // Si la lista no tiene al menos 12 nodos, no se puede comenzar la enumeración
	        return;
	    }
	    
	    int j = 1;
	    while(actual != null) {
	        System.out.println(j + ". " + actual.getVehiculo().getNombreEspanol());
	        actual = actual.getProximo();
	        j++;
	    }
	}


	
	
	public void enumerarElementoNodo(Nodo lista,int opcion) {
		Nodo actual = buscarNodo(lista,opcion);
		
		if (actual != null) {
			int j = 1;
			System.out.println(j+". Nombre en espanol: "+actual.getVehiculo().getNombreEspanol());
			j++;
			System.out.println(j+". Nombre en ingles: "+actual.getVehiculo().getNombreIngles());
			j++;
			System.out.println(j+". Nombre de o los conductores: "+actual.getVehiculo().getNombreConductor());
			j++;
			System.out.println(j+". Tipo de Caucho: "+actual.getVehiculo().getTipoCaucho());
			j++;
			System.out.println(j+". Tamano de Caucho: "+actual.getVehiculo().getTamanoCaucho());
			j++;
			System.out.println(j+". Velocidad del Vehiculo: "+actual.getVehiculo().getVelocidad());
			j++;
		}
	}
	
	
	public void imprimirListaCarros() {
		Nodo aux = lista;
		while (aux != null) {
			System.out.println(aux.getVehiculo().getNombreEspanol()+ " " +aux.getVehiculo().getNombreIngles() + " "+ aux.getVehiculo().getTamanoCaucho() + 
					" "+ aux.getVehiculo().getTamanoCaucho() + " " + aux.getVehiculo().getTipoCaucho() + " " + aux.getVehiculo().getVelocidad()
					+ aux.getVehiculo().getResObstaculos() + " "+ aux.getVehiculo().getResLiquido() + " "+aux.getVehiculo().getResExplosivos()+ " "+aux.getVehiculo().getVelocidadkm());
			aux=aux.getProximo();
		}
	}
	
	public void eliminarNodo(Nodo lista,int opcion) throws IOException {
		Nodo actual = lista;
		Nodo anterior = null;
		int i=1;
		while(actual != null && i != opcion) {
			anterior = actual;
			actual = actual.getProximo();
			i++;
		}
		
		if (actual != null) {
			if (anterior == null) {
				lista = actual.getProximo();
			}else {
				anterior.setProximo(actual.getProximo());
			}
			actualizarArchivo(lista);
		}
	}
	
	public void mostrar(Nodo lista) {
		Nodo actual = lista;
		System.out.println("Nombre en espanol: "+actual.getVehiculo().getNombreEspanol());
		System.out.println("Nombre en ingles: "+actual.getVehiculo().getNombreIngles());
		System.out.println("Nombre de o los conductores: "+actual.getVehiculo().getNombreConductor());
		System.out.println("Tipo de Caucho: "+actual.getVehiculo().getTipoCaucho());
		System.out.println("Tamano de Caucho: "+actual.getVehiculo().getTamanoCaucho());
		System.out.println("Velocidad: "+actual.getVehiculo().getVelocidad());
		System.out.println("Resistencia a Obstaculos: "+actual.getVehiculo().getResObstaculos());
		System.out.println("Resistencia a Liquidos: "+actual.getVehiculo().getResLiquido());
		System.out.println("Resistencia a Bombas: "+actual.getVehiculo().getResExplosivos());
		System.out.println("Velocidad en km/h: "+actual.getVehiculo().getVelocidadkm());
	}
	
	public void mostrarNodo(Nodo lista,int opcion) {
		Nodo aux = buscarNodo(lista,opcion);
		mostrar(aux);
	}
	
	public void mostrarDatosAgregados(Nodo lista) {
		Nodo actual = lista;
		while(actual.getProximo() != null) {
			actual = actual.getProximo();
		}
		mostrar(actual);
	}
	
	

}
