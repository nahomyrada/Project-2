package Carrera;


public class Lista {
	private Nodo lista;
	private int cantCarros;
	
	public Lista() {
		lista = null;
		cantCarros = 0;
	}
	
	public boolean esVacia() {
		boolean log = false;
		if (lista == null)
			log =  true;
		
		return log;
	}
	public void insertarFinal(Carro infoCarro) {
		Nodo nuevo = new Nodo(infoCarro,null);
		if (lista == null) 
			lista = nuevo;
		else{
			Nodo aux = lista;
			while(aux.getSiguiente() != null) {
				aux =aux.getSiguiente();
			}	
			aux.setSiguiente(nuevo);
		}
	}
	public Nodo getLista() {
		return lista;
	}
	public void setLista(Nodo aux) {
		lista=aux;
	}
	public void imprimirListaCarros() {
		Nodo aux = lista;
		while (aux != null) {
			System.out.println(aux.getCarro().getNombreEspanol()+ " " +aux.getCarro().getNombreIngles() + " "+ aux.getCarro().getTamanoCaucho() + " "+ aux.getCarro().getTamanoCaucho()+ " " + aux.getCarro().getTiempoDVelocidad() + " " + aux.getCarro().getTipoCaucho() + " " + aux.getCarro().getFigura()+ " " + aux.getCarro().getVelocidad());
			aux=aux.getSiguiente();
		}
	}
}
