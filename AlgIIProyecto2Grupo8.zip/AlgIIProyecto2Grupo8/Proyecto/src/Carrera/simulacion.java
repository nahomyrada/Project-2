package Carrera;

import java.util.Scanner;

import java.lang.Math;
import javax.swing.JOptionPane;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Random;
import javax.swing.*;

public class simulacion {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		Lista listaCarros = new Lista();
			System.out.println("Bienvenido a AUTOS LOCOS 2");
			listaCarros = leerArchivo(listaCarros);
			
			System.out.println("MENU");
			System.out.println("1. Carros aleatorios");
			System.out.println("2. Carros seleccionados");
			System.out.println("3. Salir");
			int opcionLista = scanner.nextInt();
			Lista nuevaLista = new Lista();
			
			switch(opcionLista) {
				case 1: 			
					System.out.println("Introduzca la cantidad de carros");
						int cantidadCarros = scanner.nextInt(); 
						listaAleatoria(listaCarros,nuevaLista,cantidadCarros);
						nuevaLista.imprimirListaCarros();
					break;
				case 2: enumerarNodos(listaCarros); 
				int opcionCarro;
					do {
					System.out.println("Seleccione una opcion: ");
					opcionCarro = scanner.nextInt();
						if (opcionCarro != 0) {
							listaSeleccionada(listaCarros, opcionCarro,nuevaLista);
							nuevaLista.imprimirListaCarros();
						}
					}while(opcionCarro != 0);
				break;
				case 3: break;
			}
			
			System.out.println("\nIntroduzca la cantidad de niveles del arbol: ");
			int cantNiveles = scanner.nextInt();
			
			
			Arbol arbol = new Arbol();
			generarPista(arbol, cantNiveles);
		 
			Nodo auxiliar = listaCarros.getLista();
			int cont=0;
			while(auxiliar!=null) {
				
				arbol.getRaiz().setCarro(true);
				
				while(cont!=5) {
				cont++;
				
		        ArbolGrafica arbolGrafico = new ArbolGrafica(arbol.getRaiz(),auxiliar);
		      
			        JFrame frame = new JFrame();
			        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			        frame.setSize(800, 600);
			        
			    
			        frame.add(arbolGrafico);
			        
			     
			        frame.setVisible(true);
			        auxiliar=auxiliar.getSiguiente();
			        moverCarro(arbol.getRaiz());
				}
			} 		
		scanner.close();	
	}
	/*************************************************************/
	public static Lista leerArchivo(Lista lista) {
        String nombreArchivo = "autosLocos2.txt";
        int cont=0;
        Carro carroTemporal = new Carro();
        Lista listaCarros = new Lista();
        try (Scanner scanner = new Scanner(new File(nombreArchivo))) {
            
            while (scanner.hasNextLine()) {
                String linea = scanner.nextLine(); cont++;
                switch(cont) {
                	case 1: carroTemporal.setNombreEspanol(linea); break;
                	case 2: carroTemporal.setNombreIngles(linea); break;
                	case 3: carroTemporal.setNombreConductor(linea); break;
                	case 4: carroTemporal.setTipoCaucho(linea); break;
                	case 5: carroTemporal.setTamanoCaucho(linea); break;
                	case 6: carroTemporal.setVelocidad(linea); break;
                	case 7: carroTemporal.setFigura(linea.charAt(0)); 
                	carroTemporal.setTiempoDVelocidad(0); cont = 0; 
                	Carro copiaCarroTemporal = new Carro(carroTemporal);
                	listaCarros.insertarFinal(copiaCarroTemporal); 
                	break;
                }
            }
        } catch (FileNotFoundException e) {
            System.err.println("Archivo no encontrado: " + e.getMessage());
	        }
	    return listaCarros;
	}
	public static void moverCarro(NodoArbol raiz) {
	        if ((raiz == null) || (raiz.getHijoDerecho()==null)||(raiz.getHijoIzquierdo()==null)) {
	        	raiz.setCarro(false);
	            return;
	        }
	        moverCarro(raiz.getHijoIzquierdo());
	        try {
	            Thread.sleep(300);
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
	        if(raiz.getCarro()==true) {
	        	raiz.setCarro(false);
	        	int camino =numeroAleatorio(2,1);
	        	if(camino==2) {
	        		raiz.getHijoDerecho().setCarro(true);
	        	}else {
	        		raiz.getHijoIzquierdo().setCarro(true);
	        	}
	        }
	        moverCarro(raiz.getHijoDerecho());
	        try {
	            Thread.sleep(300);
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
	}
	public static void enumerarNodos(Lista lista) {
		Nodo aux = lista.getLista();
		int i = 1;
		
		while (aux != null) {
			System.out.println(i + ". " + aux.getCarro().getFigura() + " " + aux.getCarro().getNombreEspanol() );
			aux = aux.getSiguiente();
			i++;
		}
	
	}
	public static void listaSeleccionada(Lista lista, int seleccionado, Lista carrosSeleccionados) {
	    Nodo aux=lista.getLista();
        for (int i=1;i<=seleccionado;i++){
            if (i==seleccionado) {
            		carrosSeleccionados.insertarFinal(aux.getCarro());
                    break;
        }
        aux=aux.getSiguiente();      
        }
	}
	public static void listaAleatoria(Lista lista, Lista carrosAleatorios, int cantCarros) {
	    for (int i=1;i<=cantCarros;i++){
	        int cont=0;
	        Nodo aux=lista.getLista();
	        int numero=numeroAleatorio(11,1); 
	            while (aux!=null){
	                cont++;
	                if (cont==numero){
	                   
	                     carrosAleatorios.insertarFinal(aux.getCarro());
	                     break;
	                    
	                }else
	                    aux=aux.getSiguiente();
	            }       
	    }
	}
    public static int numeroAleatorio(int maximo, int minimo) {
        Random rand = new Random();
        int num = rand.nextInt(maximo - minimo + 1) + minimo;
        return num;
    }
    
    public static void generarPista(Arbol pista, int niveles) {
    	double cantNodos = Math.pow(2, niveles+1);
    	cantNodos=(int)cantNodos; 
        for(int i = 1; i <= cantNodos-1; i++ ){
            int dato = numeroAleatorio(10000,1);
            pista.insertar(dato);
        }
    }
    
    public static void agregarTrampas(NodoArbol raiz, int cantTrampas, int cantNiveles) {
    	int trampasAñadidas=0;
    	do {
    	int nivelTrampa = numeroAleatorio(cantNiveles-1, 2);
    	trampasAñadidas=trampasEnNivel(raiz,0, nivelTrampa, trampasAñadidas);
    	}while(cantTrampas>trampasAñadidas);
    }
    public static int trampasEnNivel(NodoArbol raiz,int nivel, int nivelDeterminado, int trampasAñadidas) {
        if (raiz == null) {
            return 0;
        }else {
	        trampasAñadidas=1+ trampasEnNivel(raiz.getHijoIzquierdo(), nivel+1, nivelDeterminado,trampasAñadidas);
	        if(nivel==nivelDeterminado-1) {
	        	trampasAñadidas++;
	        	int dereOIzquie = numeroAleatorio(2,1);
	        	System.out.print(dereOIzquie);
	        	if (dereOIzquie == 1) {
	        		raiz.getHijoIzquierdo().setTrampa(true);
	        	}else {
	        		raiz.getHijoDerecho().setTrampa(true);
	        	}
	        }
	     
	        trampasAñadidas=1+ trampasEnNivel(raiz.getHijoDerecho(),nivel+1, nivelDeterminado,trampasAñadidas);
		}
        return trampasAñadidas;
    }
}

