package Carrera;

public class Nodo { 
    private Carro carro;
    private Nodo siguiente;
    
	public Nodo() {
		// TODO Auto-generated constructor stub
	}
	public Nodo(Carro carro, Nodo proximo) {
		super();
		this.carro = carro;
		this.siguiente = proximo;
	}

	public Carro getCarro() {
		return carro;
	}

	public void setCarro(Carro carro) {
		this.carro = carro;
	}

	public Nodo getSiguiente() {
		return siguiente;
	}

	public void setSiguiente(Nodo siguiente) {
		this.siguiente = siguiente;
	}
	
}
