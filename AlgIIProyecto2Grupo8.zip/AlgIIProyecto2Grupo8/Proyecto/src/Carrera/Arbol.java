package Carrera;

import javax.swing.JPanel;

public class Arbol{
	private NodoArbol raiz;
	
	public Arbol(){ 
		raiz=null;
	}
	public NodoArbol getRaiz() {
		return raiz;
	}
	
	public Arbol(NodoArbol raiz) {	
	 this.raiz = raiz;
	}
	
	public void imprimirNivel(int nivel){
		imprimirNodosEnNivel(raiz, nivel);
	}
	 public void imprimirNodosEnNivel(NodoArbol raiz, int nivel) {
			    if (raiz == null) {
			        return;
			    }
			    if (nivel == 1) {
			        System.out.print(raiz.getDato() + " ");
			    } else if (nivel > 1) {
			        imprimirNodosEnNivel(raiz.getHijoIzquierdo(), nivel - 1);
			        imprimirNodosEnNivel(raiz.getHijoDerecho(), nivel - 1);
			    }
	 }		

    public int esHoja(){
    	return Hoja(raiz);
    }
    
    private int Hoja (NodoArbol raiz){
    	if(raiz !=null){
    		if ((raiz.getHijoIzquierdo()== null)&&(raiz.getHijoDerecho()== null))
    			return 1;
    		else 
    			return Hoja(raiz.getHijoIzquierdo()) + Hoja(raiz.getHijoDerecho());
    	}
		return 0;
    }
    
    public int cantRamas(){
    	return Ramas(raiz)-1;
    }
    
    private int Ramas(NodoArbol raiz){
    	if (raiz!=null){
    		if((raiz.getHijoIzquierdo()== null)&&(raiz.getHijoDerecho()== null))
    			return 1;
    		else {
    			int ramaIzq=Ramas(raiz.getHijoIzquierdo());
    			int ramaDer=Ramas(raiz.getHijoDerecho());
    			return 1+ramaIzq+ramaDer;
    		}
    	}
		return 0;    
    }   
 

    private NodoArbol recorrerIzquierda(NodoArbol nodo) {
        if (nodo.getHijoIzquierdo() != null) {
            return recorrerIzquierda( nodo.getHijoIzquierdo() );
        }
        return nodo;
    }

public NodoArbol buscar(int d, NodoArbol r) {
	   if(raiz==null) {
		   return null;
	   }
	   else if(r.getDato() == d) {
		   return r;
	   }
	   else if(r.getDato()<d) {
		   return buscar(d,r.getHijoDerecho());
	   }
	   else {
		   return buscar(d,r.getHijoIzquierdo());
	   }
}



public int obtenerFE (NodoArbol x) {
	   if(x==null) {
		   return -1;		   
	   } else {
		   return x.getFe();
	   }
}



public NodoArbol rotacionIzquierda(NodoArbol c) {
	   NodoArbol aux = c.getHijoIzquierdo();
	   c.setHijoIzquierdo(aux.getHijoDerecho());
	   aux.setHijoDerecho(c);
	   c.setFe(Math.max(obtenerFE(c.getHijoIzquierdo()), obtenerFE(c.getHijoDerecho()))+1);
	   aux.setFe(Math.max(obtenerFE(aux.getHijoIzquierdo()), obtenerFE(aux.getHijoDerecho()))+1);
	   return aux;
}



public NodoArbol rotacionDerecha(NodoArbol c) {
	   NodoArbol aux = c.getHijoDerecho();
	   c.setHijoDerecho(aux.getHijoIzquierdo());
	   aux.setHijoIzquierdo(c);
	   c.setFe(Math.max(obtenerFE(c.getHijoDerecho()), obtenerFE(c.getHijoIzquierdo()))+1);
	   aux.setFe(Math.max(obtenerFE(aux.getHijoIzquierdo()), obtenerFE(aux.getHijoDerecho()))+1);
	   return aux;
}



public NodoArbol rotacionDobleIzquierda (NodoArbol c) {
	   NodoArbol aux;
	   c.setHijoIzquierdo(rotacionDerecha(c.getHijoIzquierdo()));
	   aux = rotacionIzquierda(c);
	   return aux;
}



public NodoArbol rotacionDobleDerecha (NodoArbol c) {
	   NodoArbol aux;
	   c.setHijoDerecho(rotacionIzquierda(c.getHijoDerecho()));
	   aux = rotacionDerecha(c);
	   return aux;
}

public NodoArbol insertarAVL(NodoArbol nuevo, NodoArbol subAr) {
	   NodoArbol nuevoPadre = subAr;
	   if(nuevo.getDato()<subAr.getDato()) {
		  if (subAr.getHijoIzquierdo()==null) {
			  subAr.setHijoIzquierdo(nuevo);
		  } else {
			  subAr.setHijoIzquierdo(insertarAVL(nuevo,subAr.getHijoIzquierdo()));
			  if(obtenerFE(subAr.getHijoIzquierdo()) - obtenerFE(subAr.getHijoDerecho())== 2){
				  if(nuevo.getDato() < subAr.getHijoIzquierdo().getDato()) {
			    	nuevoPadre=rotacionIzquierda(subAr);
				  }else {
			    	nuevoPadre=rotacionDobleIzquierda(subAr);
			    }
			  }
		  	}
	   }else if(nuevo.getDato()>subAr.getDato()) {
		   if (subAr.getHijoDerecho()==null) {
			   subAr.setHijoDerecho(nuevo);
		   }else {
			   subAr.setHijoDerecho(insertarAVL(nuevo,subAr.getHijoDerecho()));
			   if((obtenerFE(subAr.getHijoDerecho())-obtenerFE(subAr.getHijoIzquierdo()))==2) {
				   if(nuevo.getDato()>subAr.getHijoDerecho().getDato()) {
					   nuevoPadre = rotacionDerecha(subAr);
				   }else {
					   nuevoPadre = rotacionDobleDerecha(subAr);
				   }
			   }
		   }
	   }
	
	   if((subAr.getHijoIzquierdo()==null)&&(subAr.getHijoDerecho()!=null)) {
		   subAr.setFe(subAr.getHijoDerecho().getFe()+1);
	   }else if((subAr.getHijoDerecho()==null)&&(subAr.getHijoIzquierdo()!=null)) {
		   subAr.setFe(subAr.getHijoIzquierdo().getFe()+1);
	   }else {
		   subAr.setFe(Math.max(obtenerFE(subAr.getHijoIzquierdo()),obtenerFE(subAr.getHijoDerecho()))+1);
	   }
	   return nuevoPadre;
}
public void insertar(int d) {
	  NodoArbol nuevo = new NodoArbol(d);
	  if (raiz==null) {
		  raiz=nuevo;
	  }else {
		  raiz=insertarAVL(nuevo,raiz);
	  }
}
}
