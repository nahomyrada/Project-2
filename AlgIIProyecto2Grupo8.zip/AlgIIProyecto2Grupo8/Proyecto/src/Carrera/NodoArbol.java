package Carrera;

public class NodoArbol{

	private int dato;
	private Boolean trampa;
	private int fe;
	private NodoArbol hijoDerecho;
	private NodoArbol hijoIzquierdo;
	private Boolean carro;
	
	public NodoArbol() {
		
	}
	public NodoArbol(int clave){
		dato=clave;
		fe=0;
		trampa = false;
		hijoIzquierdo = hijoDerecho = null;
		carro=false;
	}
	public boolean getCarro() {
		return carro;
	}
	public void setCarro(Boolean aux) {
		carro=aux;
	}
	public int getFe() {
		return fe;
	}
	public void setFe(int valor) {
		fe=valor;
	}
	public Boolean getTrampa() {
		return trampa;
	}
	public void setTrampa(Boolean trampa) {
		this.trampa = trampa;
	}
	public int getDato() {		
		return dato;
	}

	public void setDato(int dato) {
		this.dato = dato;
	}

	public NodoArbol getHijoDerecho() {
		return hijoDerecho;
	}

	public void setHijoDerecho(NodoArbol hijoDerecho) {
		this.hijoDerecho = hijoDerecho;
	}

	public NodoArbol getHijoIzquierdo() {
		return hijoIzquierdo;
	}

	public void setHijoIzquierdo(NodoArbol hijoIzquierdo) {
		this.hijoIzquierdo = hijoIzquierdo;
	}

	
	public NodoArbol getPadre() {
		return null;
	}
	
	public void setPadre(NodoArbol nodo) {

	}	
}