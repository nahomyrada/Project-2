package Carrera;

public class Carro {
    private String nombreEspanol;
    private String nombreIngles;
    private String nombreConductor;
    private char figura;
    private String tipoCaucho;
    private String tamanoCaucho;
    private String velocidad;
    private int tiempoDVelocidad;
    
	public Carro() {
		// TODO Auto-generated constructor stub
	}
	public Carro(Carro copia) {
		this.nombreEspanol = copia.nombreEspanol;
		this.nombreIngles = copia.nombreIngles;
		this.nombreConductor = copia.nombreConductor;
		this.figura = copia.figura;
		this.tipoCaucho = copia.tipoCaucho;
		this.tamanoCaucho = copia.tamanoCaucho;
		this.velocidad = copia.velocidad;
		this.tiempoDVelocidad = copia.tiempoDVelocidad;
	}
	public Carro(String nombreEspanol, String nombreIngles, String nombreConductor, char figura, String tipoCaucho,
			String tamanoCaucho, String velocidad, int tiempoDVelocidad, Nodo siguiente) {
		super();
		this.nombreEspanol = nombreEspanol;
		this.nombreIngles = nombreIngles;
		this.nombreConductor = nombreConductor;
		this.figura = figura;
		this.tipoCaucho = tipoCaucho;
		this.tamanoCaucho = tamanoCaucho;
		this.velocidad = velocidad;
		this.tiempoDVelocidad = tiempoDVelocidad;
	}



	public String getNombreEspanol() {
		return nombreEspanol;
	}

	public void setNombreEspanol(String nombreEspanol) {
		this.nombreEspanol = nombreEspanol;
	}

	public String getNombreIngles() {
		return nombreIngles;
	}

	public void setNombreIngles(String nombreIngles) {
		this.nombreIngles = nombreIngles;
	}

	public String getNombreConductor() {
		return nombreConductor;
	}

	public void setNombreConductor(String nombreConductor) {
		this.nombreConductor = nombreConductor;
	}

	public char getFigura() {
		return figura;
	}

	public void setFigura(char figura) {
		this.figura = figura;
	}

	public String getTipoCaucho() {
		return tipoCaucho;
	}

	public void setTipoCaucho(String tipoCaucho) {
		this.tipoCaucho = tipoCaucho;
	}

	public String getTamanoCaucho() {
		return tamanoCaucho;
	}

	public void setTamanoCaucho(String tamanoCaucho) {
		this.tamanoCaucho = tamanoCaucho;
	}

	public String getVelocidad() {
		return velocidad;
	}

	public void setVelocidad(String velocidad) {
		this.velocidad = velocidad;
	}

	public int getTiempoDVelocidad() {
		return tiempoDVelocidad;
	}

	public void setTiempoDVelocidad(int tiempoDVelocidad) {
		this.tiempoDVelocidad = tiempoDVelocidad;
	}
}
