package Carrera;

import java.awt.*;
import javax.swing.*;

public class ArbolGrafica extends JPanel {
    private NodoArbol raiz;
    private int diametro = 20;
    private int radio = diametro / 2;
    private int espacioEntreNodos = 50;
    private Nodo carro;

    public ArbolGrafica(NodoArbol raiz, Nodo carro) {
        this.raiz = raiz;
        this.setBackground(Color.PINK);
        this.carro=carro;
    }

 
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        dibujarArbol(g, getWidth() / 2, 40, raiz);
    }

    private void dibujarArbol(Graphics g, int x, int y, NodoArbol nodo) {
        if (nodo == null) return;

        int textoRadio = g.getFontMetrics().stringWidth(String.valueOf(nodo.getDato())) / 2;
        g.drawOval(x - radio, y - radio, diametro, diametro);
        
        if (nodo.getCarro()==true) {
        	g.drawString(String.valueOf(carro.getCarro().getFigura()), x - textoRadio, y + 4); // 
        }
        if (nodo.getHijoIzquierdo() != null) {
            conectarNodos(g, x - espacioEntreNodos, y + espacioEntreNodos, x, y);
            dibujarArbol(g, x - espacioEntreNodos, y + espacioEntreNodos, nodo.getHijoIzquierdo());
        }

        if (nodo.getHijoDerecho() != null) {
            conectarNodos(g, x + espacioEntreNodos, y + espacioEntreNodos, x, y);
            dibujarArbol(g, x + espacioEntreNodos, y + espacioEntreNodos, nodo.getHijoDerecho());
        }
    }

    private void conectarNodos(Graphics g, int x1, int y1, int x2, int y2) {
        double d = Math.sqrt(espacioEntreNodos * espacioEntreNodos + espacioEntreNodos * espacioEntreNodos);
        int dx = (int) (radio * (x2 - x1) / d);
        int dy = (int) (radio * (y2 - y1) / d);
        g.drawLine(x1 + dx, y1 + dy, x2 - dx, y2 - dy);
    }
}
